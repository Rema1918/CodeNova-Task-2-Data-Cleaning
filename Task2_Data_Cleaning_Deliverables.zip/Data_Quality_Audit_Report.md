# Task 2: Data Quality Audit Report

## 1. Project Overview
This project audits and cleans the UCI Online Retail dataset.
The original raw dataset is preserved separately.

## 2. Dataset Summary
- Original rows: 541909
- Cleaned rows: 524878
- Original columns: 8
- Cleaned columns: 8
- Rows removed: 17031

## 3. Cleaning Steps
1. Inspected missing values, data types, and duplicate rows.
2. Removed exact duplicate records.
3. Standardized invoice dates and numeric columns.
4. Trimmed extra spaces from selected text columns.
5. Removed rows with missing or invalid invoice dates,
   quantities, or unit prices.
6. Detected Quantity and UnitPrice outliers using the IQR method.
7. Saved the cleaned dataset separately from the raw file.

## 4. Cleaning Rationale
- Exact duplicates were removed to prevent double counting.
- Invalid dates were removed because they cannot support reliable
  date-based analysis.
- Non-positive quantities and prices were excluded from this
  positive-sales dataset; returns and cancellations require
  separate business treatment.
- IQR outliers were reported, not automatically removed, because
  extreme values may represent genuine transactions.
- Missing values were inspected; remaining missing values should
  be reviewed before downstream analysis.

## 5. Outlier Analysis
The IQR outlier counts are available in `iqr_outlier_report.csv`.
Outliers were retained unless they were invalid under the documented
rules above.

## 6. Deliverables
- `online_retail_cleaned.csv`
- `before_cleaning_metrics.csv`
- `before_after_comparison.csv`
- `missing_values_report.csv`
- `iqr_outlier_report.csv`

## 7. Limitations
The cleaning rules focus on positive sales transactions.
The original raw dataset remains unchanged. All cleaning steps can
be rerun using the notebook cells in order.

## 8. Conclusion
The workflow documents data quality issues, cleaning decisions,
outlier detection, and before-and-after metrics for reproducible
data preparation.
